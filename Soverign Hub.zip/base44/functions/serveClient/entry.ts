const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { createClientFromRequest } from 'npm:@base44/sdk@0.8.44';

// Serves an uploaded client's HTML from this app's own origin.
// Clients served from the file-storage origin get rejected by most
// Minecraft web servers when they open their server connection, which
// crashes the game on join — serving through this proxy gives every
// client the app's origin instead. Anyone can reach this endpoint, but
// it only maps unguessable record ids to files that are already public.
export default async function(req: Request): Promise<Response> {
  try {
    const url = new URL(req.url);
    let id = url.searchParams.get('id') || '';
    if (req.method === 'POST') {
      const body = await req.json().catch(() => ({}));
      id = body?.id || id;
    }
    if (!id || !/^[a-zA-Z0-9_-]{6,64}$/.test(id)) {
      return Response.json({ error: 'Bad request' }, { status: 400 });
    }
    const base44 = createClientFromRequest(req);
    const client = await db.asServiceRole.entities.ClientFile.get(id);
    if (!client || !client.file_url) {
      return Response.json({ error: 'Client not found' }, { status: 404 });
    }
    const upstream = await fetch(client.file_url);
    if (!upstream.ok) {
      return Response.json({ error: 'Client file unavailable' }, { status: 502 });
    }
    let html = await upstream.text();
    // Some client builds ship a script that detects iframes and redirects
    // to a relative page (e.g. './launch.html'). Through this proxy that
    // page doesn't exist, so the client would 404 the moment it loads.
    // Drop those escape scripts so the client stays on the page we serve.
    html = html.replace(
      /<script\b[^>]*>(?:(?!<\/script>)[\s\S])*?window\.top\s*(?:!==|!=)\s*window\.self(?:(?!<\/script>)[\s\S])*?<\/script>/gi,
      ''
    );
    return new Response(html, {
      status: 200,
      headers: {
        'Content-Type': 'text/html; charset=utf-8',
        'Cache-Control': 'public, max-age=3600',
      },
    });
  } catch (error) {
    return Response.json({ error: String(error) }, { status: 500 });
  }
}