import { useEffect, useRef, useState } from 'react';
import { REGIONS } from '@/lib/skinRegions';

const SIZE = 64;
const DRAFT_KEY = 'sovereign-skin-draft';

function hexToRgba(hex) {
  const h = (hex || '#000000').replace('#', '');
  return [
    parseInt(h.slice(0, 2), 16),
    parseInt(h.slice(2, 4), 16),
    parseInt(h.slice(4, 6), 16),
    255,
  ];
}

// Blank skin: every base body part solid white, everything else transparent.
function fillBlank(pixels) {
  pixels.fill(0);
  for (const part of Object.values(REGIONS)) {
    for (const [fx, fy, fw, fh] of part.faces) {
      for (let y = fy; y < fy + fh; y++) {
        for (let x = fx; x < fx + fw; x++) {
          const i = (y * SIZE + x) * 4;
          pixels[i] = 255;
          pixels[i + 1] = 255;
          pixels[i + 2] = 255;
          pixels[i + 3] = 255;
        }
      }
    }
  }
}

// Single source of truth for the 64x64 skin pixels. Both the 2D texture
// canvas and the 3D model paint through this editor so they always match,
// and the offscreen canvas is already in the standard Minecraft format.
// Work in progress is also kept in local storage, so switching tabs (or a
// page refresh) never loses the skin you were painting.
export function useSkinEditor({ onPick } = {}) {
  const skinCanvasRef = useRef(null);
  if (!skinCanvasRef.current) {
    const c = document.createElement('canvas');
    c.width = SIZE;
    c.height = SIZE;
    skinCanvasRef.current = c;
  }
  const skinCanvas = skinCanvasRef.current;

  const pixelsRef = useRef(new Uint8ClampedArray(SIZE * SIZE * 4));
  const historyRef = useRef([]);
  const hIndexRef = useRef(-1);
  const drawingRef = useRef(false);
  const initRef = useRef(false);
  const [version, setVersion] = useState(0);
  const [canUndo, setCanUndo] = useState(false);
  const [canRedo, setCanRedo] = useState(false);

  const redrawSkin = () => {
    const ctx = skinCanvas.getContext('2d');
    ctx.putImageData(new ImageData(pixelsRef.current, SIZE, SIZE), 0, 0);
  };

  if (!initRef.current) {
    initRef.current = true;
    fillBlank(pixelsRef.current);
    historyRef.current = [new Uint8ClampedArray(pixelsRef.current)];
    hIndexRef.current = 0;
    redrawSkin();
  }

  const commit = () => {
    redrawSkin();
    try { localStorage.setItem(DRAFT_KEY, skinCanvas.toDataURL('image/png')); } catch { /* storage full/blocked */ }
    setVersion((v) => v + 1);
  };

  const syncFlags = () => {
    setCanUndo(hIndexRef.current > 0);
    setCanRedo(hIndexRef.current < historyRef.current.length - 1);
  };

  const pushHistory = () => {
    const h = historyRef.current.slice(0, hIndexRef.current + 1);
    h.push(new Uint8ClampedArray(pixelsRef.current));
    if (h.length > 40) h.shift();
    historyRef.current = h;
    hIndexRef.current = h.length - 1;
  };

  const floodFill = (x, y, hex) => {
    const p = pixelsRef.current;
    const i0 = (y * SIZE + x) * 4;
    const tr = p[i0], tg = p[i0 + 1], tb = p[i0 + 2], ta = p[i0 + 3];
    const [fr, fg, fb] = hexToRgba(hex);
    const fa = 255;
    if (tr === fr && tg === fg && tb === fb && ta === fa) return;
    const stack = [[x, y]];
    while (stack.length) {
      const [cx, cy] = stack.pop();
      if (cx < 0 || cx >= SIZE || cy < 0 || cy >= SIZE) continue;
      const i = (cy * SIZE + cx) * 4;
      if (p[i] !== tr || p[i + 1] !== tg || p[i + 2] !== tb || p[i + 3] !== ta) continue;
      p[i] = fr; p[i + 1] = fg; p[i + 2] = fb; p[i + 3] = fa;
      stack.push([cx + 1, cy], [cx - 1, cy], [cx, cy + 1], [cx, cy - 1]);
    }
  };

  const applyAt = (x, y, tool, color) => {
    if (x < 0 || x >= SIZE || y < 0 || y >= SIZE) return;
    const p = pixelsRef.current;
    const i = (y * SIZE + x) * 4;
    if (tool === 'pencil') {
      const [r, g, b] = hexToRgba(color);
      p[i] = r; p[i + 1] = g; p[i + 2] = b; p[i + 3] = 255;
    } else if (tool === 'eraser') {
      p[i + 3] = 0;
    } else if (tool === 'fill') {
      floodFill(x, y, color);
    } else if (tool === 'eyedropper') {
      if (p[i + 3] === 0) { onPick?.(null); return; }
      const hex = '#' + [p[i], p[i + 1], p[i + 2]].map((v) => v.toString(16).padStart(2, '0')).join('');
      onPick?.(hex);
      return;
    }
    commit();
  };

  // Load any image (imported PNG, saved skin) into the editor as the new skin.
  const loadFromImage = (img) => {
    const ctx = skinCanvas.getContext('2d');
    ctx.clearRect(0, 0, SIZE, SIZE);
    ctx.imageSmoothingEnabled = false;
    ctx.drawImage(img, 0, 0, SIZE, SIZE);
    pixelsRef.current.set(ctx.getImageData(0, 0, SIZE, SIZE).data);
    pushHistory();
    commit();
    syncFlags();
  };

  // Restore the unsaved draft (tab switches / refreshes).
  useEffect(() => {
    const draft = localStorage.getItem(DRAFT_KEY);
    if (!draft) return;
    const img = new Image();
    img.onload = () => loadFromImage(img);
    img.src = draft;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return {
    skinCanvas,
    version,
    canUndo,
    canRedo,
    loadFromImage,
    beginStroke: (x, y, tool, color) => {
      if (tool === 'eyedropper') { applyAt(x, y, tool, color); return; }
      drawingRef.current = true;
      applyAt(x, y, tool, color);
    },
    moveStroke: (x, y, tool, color) => {
      if (!drawingRef.current) return;
      if (tool === 'fill' || tool === 'eyedropper') return;
      applyAt(x, y, tool, color);
    },
    endStroke: () => {
      if (!drawingRef.current) return;
      drawingRef.current = false;
      pushHistory();
      syncFlags();
    },
    undo: () => {
      if (hIndexRef.current > 0) {
        hIndexRef.current -= 1;
        pixelsRef.current.set(historyRef.current[hIndexRef.current]);
        commit();
        syncFlags();
      }
    },
    redo: () => {
      if (hIndexRef.current < historyRef.current.length - 1) {
        hIndexRef.current += 1;
        pixelsRef.current.set(historyRef.current[hIndexRef.current]);
        commit();
        syncFlags();
      }
    },
    clear: () => {
      pixelsRef.current.fill(0);
      pushHistory();
      commit();
      syncFlags();
    },
  };
}