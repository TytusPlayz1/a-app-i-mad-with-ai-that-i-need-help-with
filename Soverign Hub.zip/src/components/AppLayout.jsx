import React from 'react';
import { NavLink, Outlet } from 'react-router-dom';
import { Gamepad2, Palette, Home, Settings as SettingsIcon } from 'lucide-react';
import { GameSessionProvider } from '@/lib/GameSessionContext';
import GameFrame from '@/components/client-loader/GameFrame';

const TABS = [
  { to: '/', label: 'Home', icon: Home, end: true },
  { to: '/client-loader', label: 'Client Loader', icon: Gamepad2, end: true },
  { to: '/skin-maker', label: 'Skin Maker', icon: Palette, end: false },
  { to: '/settings', label: 'Settings', icon: SettingsIcon, end: true },
];

export default function AppLayout() {
  return (
    <GameSessionProvider>
      <div className="pixel-bg min-h-screen bg-slate-950 text-slate-100">
        <header className="sticky top-0 z-40 border-b-2 border-slate-800 bg-slate-950/80 backdrop-blur">
          <div className="mx-auto flex h-14 max-w-6xl items-center gap-3 px-4 sm:gap-6">
            <span className="flex items-center gap-2.5">
              <span className="block h-5 w-5 border-2 border-indigo-300 bg-indigo-500 pixel-shadow-sm" />
              <span className="font-display text-sm font-bold tracking-tight">
                Sovereign<span className="text-indigo-400">Client</span>
              </span>
            </span>
            <nav className="flex gap-1">
              {TABS.map((t) => {
                const Icon = t.icon;
                return (
                  <NavLink
                    key={t.to}
                    to={t.to}
                    end={t.end}
                    className={({ isActive }) =>
                      `inline-flex items-center gap-2 px-3 py-1.5 text-sm font-medium transition ${
                        isActive
                          ? 'bg-indigo-500/15 text-indigo-300'
                          : 'text-slate-400 hover:bg-slate-800/60 hover:text-slate-200'
                      }`
                    }
                  >
                    <Icon className="h-4 w-4" /> <span className="hidden sm:inline">{t.label}</span>
                  </NavLink>
                );
              })}
            </nav>
          </div>
        </header>
        <main className="mx-auto max-w-6xl px-4 py-6">
          <Outlet />
        </main>
        {/* Persistent game iframe — survives tab switches */}
        <GameFrame />
      </div>
    </GameSessionProvider>
  );
}