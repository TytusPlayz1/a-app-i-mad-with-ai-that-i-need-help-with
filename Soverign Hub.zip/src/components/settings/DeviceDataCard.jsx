import React from 'react';
import { Trash2 } from 'lucide-react';
import { wipeGameData } from '@/lib/gameData';

// What stays on this device only: the game clients' own in-browser data
// (in-game server lists, singleplayer worlds, settings). Offer a manual
// reset for when leftover data from another client or account causes
// crashes on the multiplayer screen.
export default function DeviceDataCard() {
  const reset = async () => {
    const ok = window.confirm(
      'Reset game data? This clears in-game server lists, worlds, and settings saved by clients on this site. Your uploaded clients and skins are safe.'
    );
    if (!ok) return;
    await wipeGameData();
  };

  return (
    <div className="border-2 border-slate-800 bg-slate-900/50 p-4 pixel-shadow">
      <h2 className="text-sm font-semibold text-slate-200">This device only</h2>
      <p className="mt-0.5 text-xs text-slate-500">
        In-game progress (singleplayer worlds, server lists, client settings) is kept by the game itself in this
        browser, and it's automatically cleared when a different account signs in here. Leftovers from another
        client build can crash the server list — reset them below.
      </p>
      <button
        type="button"
        onClick={reset}
        className="mt-3 inline-flex items-center gap-1.5 border-2 border-slate-700 px-3 py-2 text-xs font-semibold text-slate-300 transition hover:bg-slate-800"
      >
        <Trash2 className="h-4 w-4" /> Reset game data
      </button>
    </div>
  );
}