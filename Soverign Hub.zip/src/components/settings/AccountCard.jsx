const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useEffect, useState } from 'react';
import { Loader2, LogOut } from 'lucide-react';

// Your account card: who's signed in, and a way to sign out. Everything
// in the app is saved to this account, not the device you're on.
export default function AccountCard() {
  const [me, setMe] = useState(null); // null = loading, false = error

  useEffect(() => {
    db.auth.me().then(setMe).catch(() => setMe(false));
  }, []);

  const initial = (me && (me.full_name || me.email || '?'))?.[0]?.toUpperCase() || '?';

  return (
    <div className="border-2 border-slate-800 bg-slate-900/50 p-4 pixel-shadow">
      <h2 className="text-sm font-semibold text-slate-200">Account</h2>
      <p className="mt-0.5 text-xs text-slate-500">
        Everything you save here belongs to this account and follows you to any device you sign in on.
      </p>
      {me === null ? (
        <div className="mt-4 flex justify-center py-4">
          <Loader2 className="h-6 w-6 animate-spin text-slate-500" />
        </div>
      ) : me === false ? (
        <p className="mt-3 text-sm text-red-300">Couldn't load your account info. Refresh the page and try again.</p>
      ) : (
        <div className="mt-4 flex items-center gap-3">
          <span className="flex h-11 w-11 shrink-0 items-center justify-center border-2 border-indigo-400/60 bg-indigo-500/15 font-display text-sm text-indigo-300 pixel-shadow-sm">
            {initial}
          </span>
          <div className="min-w-0 flex-1">
            <p className="truncate text-sm font-medium text-slate-100">{me.full_name || 'Account'}</p>
            <p className="truncate text-xs text-slate-500">{me.email}</p>
          </div>
          <button
            type="button"
            onClick={() => db.auth.logout('/login')}
            className="inline-flex shrink-0 items-center gap-1.5 border-2 border-slate-700 px-3 py-2 text-xs font-semibold text-slate-300 transition hover:bg-slate-800"
          >
            <LogOut className="h-4 w-4" /> Sign out
          </button>
        </div>
      )}
    </div>
  );
}