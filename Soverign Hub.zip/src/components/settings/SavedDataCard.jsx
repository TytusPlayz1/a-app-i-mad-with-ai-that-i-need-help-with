const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useEffect, useState } from 'react';
import { Loader2 } from 'lucide-react';

// A quick inventory of everything saved to your account — proof it lives
// on the account, not on this device.
export default function SavedDataCard() {
  const [counts, setCounts] = useState(null); // null = loading

  useEffect(() => {
    Promise.all([
      db.entities.ClientFile.list('-updated_date', 100),
      db.entities.ServerEntry.list('-updated_date', 100),
      db.entities.WorldSave.list('-updated_date', 100),
      db.entities.Skin.list('-updated_date', 100),
    ])
      .then(([clients, servers, worlds, skins]) =>
        setCounts({ clients: clients.length, servers: servers.length, worlds: worlds.length, skins: skins.length })
      )
      .catch(() => setCounts({}));
  }, []);

  const rows = [
    { key: 'clients', label: 'Clients' },
    { key: 'servers', label: 'Saved servers' },
    { key: 'worlds', label: 'World saves' },
    { key: 'skins', label: 'Skins' },
  ];

  return (
    <div className="border-2 border-slate-800 bg-slate-900/50 p-4 pixel-shadow">
      <h2 className="text-sm font-semibold text-slate-200">Saved to your account</h2>
      <p className="mt-0.5 text-xs text-slate-500">
        These follow you to any device — sign in anywhere and they're all here.
      </p>
      {counts === null ? (
        <div className="mt-4 flex justify-center py-4">
          <Loader2 className="h-6 w-6 animate-spin text-slate-500" />
        </div>
      ) : (
        <ul className="mt-3 grid grid-cols-2 gap-2">
          {rows.map((r) => (
            <li key={r.key} className="border-2 border-slate-800 bg-slate-950 px-3 py-2.5">
              <p className="font-display text-lg text-indigo-300">{counts[r.key] ?? '—'}</p>
              <p className="mt-0.5 text-xs text-slate-400">{r.label}</p>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}