import React from 'react';
import { Pencil, Eraser, PaintBucket, Pipette, Undo2, Redo2, Trash2, Grid3x3, Download } from 'lucide-react';

const TOOLS = [
  { id: 'pencil', label: 'Pencil', icon: Pencil },
  { id: 'eraser', label: 'Eraser', icon: Eraser },
  { id: 'fill', label: 'Fill', icon: PaintBucket },
  { id: 'eyedropper', label: 'Pick', icon: Pipette },
];

export default function Toolbar({
  tool, setTool, onUndo, onRedo, onClear,
  showGrid, setShowGrid, onDownload, canUndo, canRedo,
}) {
  return (
    <div className="flex flex-wrap items-center gap-2">
      <div className="flex border-2 border-slate-700 bg-slate-900/60">
        {TOOLS.map((t) => {
          const Icon = t.icon;
          const active = tool === t.id;
          return (
            <button
              key={t.id}
              type="button"
              onClick={() => setTool(t.id)}
              title={t.label}
              className={`inline-flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium transition ${
                active ? 'bg-indigo-500 text-white pixel-shadow-sm' : 'text-slate-300 hover:bg-slate-800'
              }`}
            >
              <Icon className="h-4 w-4" />
              <span className="hidden sm:inline">{t.label}</span>
            </button>
          );
        })}
      </div>

      <div className="flex border-2 border-slate-700 bg-slate-900/60">
        <button type="button" onClick={onUndo} disabled={!canUndo} title="Undo"
          className="p-1.5 text-slate-300 transition hover:bg-slate-800 disabled:opacity-40">
          <Undo2 className="h-4 w-4" />
        </button>
        <button type="button" onClick={onRedo} disabled={!canRedo} title="Redo"
          className="p-1.5 text-slate-300 transition hover:bg-slate-800 disabled:opacity-40">
          <Redo2 className="h-4 w-4" />
        </button>
        <button type="button" onClick={onClear} title="Clear"
          className="p-1.5 text-slate-300 transition hover:bg-slate-800">
          <Trash2 className="h-4 w-4" />
        </button>
        <button type="button" onClick={() => setShowGrid((s) => !s)} title="Toggle grid"
          className={`p-1.5 transition ${showGrid ? 'bg-slate-700 text-white' : 'text-slate-300 hover:bg-slate-800'}`}>
          <Grid3x3 className="h-4 w-4" />
        </button>
      </div>

      <button type="button" onClick={onDownload}
        className="ml-auto inline-flex items-center gap-2 border-2 border-indigo-400/60 bg-indigo-500 px-4 py-2 text-sm font-semibold text-white transition hover:bg-indigo-400 pixel-shadow">
        <Download className="h-4 w-4" /> Download PNG
      </button>
    </div>
  );
}