import React, { useEffect, useState } from 'react';

const PRESETS = [
  // neutrals
  '#ffffff', '#e4e4e7', '#a1a1aa', '#71717a', '#3f3f46', '#18181b', '#000000', '#6b7280', '#9ca3af', '#d4d4d8',
  // skin tones + reds + oranges
  '#ffe0bd', '#f5cba7', '#e0ac69', '#c68642', '#8d5524', '#5c3317', '#ef4444', '#dc2626', '#b91c1c', '#f97316',
  // yellows + greens + teals
  '#f59e0b', '#eab308', '#84cc16', '#22c55e', '#15803d', '#0d9488', '#14b8a6', '#38bdf8', '#3b82f6', '#1d4ed8',
  // blues + purples + pinks
  '#1e3a8a', '#8b5cf6', '#7c3aed', '#6d28d9', '#4c1d95', '#a855f7', '#c084fc', '#d946ef', '#ec4899', '#f472b6',
];

export default function ColorPalette({ color, setColor }) {
  const [hexInput, setHexInput] = useState(color);

  useEffect(() => { setHexInput(color); }, [color]);

  const applyHex = () => {
    const h = hexInput.trim().replace(/^#/, '');
    if (/^[0-9a-fA-F]{6}$/.test(h)) setColor('#' + h.toLowerCase());
    else setHexInput(color);
  };

  return (
    <div className="space-y-3">
      <div className="flex items-center gap-4">
        <label className="relative h-12 w-12 shrink-0 cursor-pointer overflow-hidden border-2 border-slate-600">
          <span className="absolute inset-0" style={{ backgroundColor: color }} />
          <input
            type="color"
            value={color}
            onChange={(e) => setColor(e.target.value)}
            className="absolute inset-0 h-full w-full cursor-pointer opacity-0"
          />
        </label>
        <div className="min-w-0 flex-1">
          <div className="text-xs font-medium text-slate-400">Custom color</div>
          <div className="mt-1 flex flex-wrap items-center gap-2">
            <input
              value={hexInput}
              onChange={(e) => setHexInput(e.target.value)}
              onBlur={applyHex}
              onKeyDown={(e) => { if (e.key === 'Enter') applyHex(); }}
              spellCheck={false}
              maxLength={7}
              className="w-28 border-2 border-slate-700 bg-slate-950 px-2 py-1 font-mono text-sm uppercase text-slate-100 focus:border-indigo-500 focus:outline-none"
            />
            <span className="text-xs text-slate-500">Click the swatch to open the color picker</span>
          </div>
        </div>
      </div>
      <div className="grid grid-cols-10 gap-1.5">
        {PRESETS.map((c) => (
          <button
            key={c}
            type="button"
            onClick={() => setColor(c)}
            title={c}
            className={`h-7 w-full border-2 transition ${
              color.toLowerCase() === c.toLowerCase()
                ? 'border-white pixel-shadow-sm'
                : 'border-slate-700 hover:scale-110'
            }`}
            style={{ backgroundColor: c }}
          />
        ))}
      </div>
    </div>
  );
}