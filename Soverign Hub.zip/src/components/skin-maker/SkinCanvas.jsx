import React, { useEffect, useRef } from 'react';

const SIZE = 64;
const PX = 11;
const DISP = SIZE * PX;

// Where each body part lives on the 64x64 texture, in texture pixels,
// so people can see which spot is the head, torso, arms, and legs.
const PART_LABELS = [
  { label: 'Head', at: [8, 8, 8, 8] },
  { label: 'Torso', at: [20, 20, 8, 12] },
  { label: 'R Arm', at: [44, 20, 4, 12] },
  { label: 'L Arm', at: [36, 52, 4, 12] },
  { label: 'R Leg', at: [4, 20, 4, 12] },
  { label: 'L Leg', at: [20, 52, 4, 12] },
];

// 2D view of the 64x64 texture. All pixel changes go through the shared
// editor so the 3D model always matches.
export default function SkinCanvas({ editor, tool, color, showGrid }) {
  const canvasRef = useRef(null);

  const redraw = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    ctx.clearRect(0, 0, DISP, DISP);
    // checkerboard background for transparency
    for (let y = 0; y < SIZE; y++) {
      for (let x = 0; x < SIZE; x++) {
        ctx.fillStyle = (x + y) % 2 === 0 ? '#e9eef5' : '#cdd6e4';
        ctx.fillRect(x * PX, y * PX, PX, PX);
      }
    }
    ctx.imageSmoothingEnabled = false;
    ctx.drawImage(editor.skinCanvas, 0, 0, DISP, DISP);
    if (showGrid) {
      ctx.strokeStyle = 'rgba(15,23,42,0.18)';
      ctx.lineWidth = 1;
      for (let i = 0; i <= SIZE; i++) {
        ctx.beginPath(); ctx.moveTo(i * PX + 0.5, 0); ctx.lineTo(i * PX + 0.5, DISP); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(0, i * PX + 0.5); ctx.lineTo(DISP, i * PX + 0.5); ctx.stroke();
      }
    }
  };

  useEffect(() => {
    redraw();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [editor.version, editor.skinCanvas, showGrid]);

  const coords = (e) => {
    const rect = canvasRef.current.getBoundingClientRect();
    const x = Math.floor((e.clientX - rect.left) / rect.width * SIZE);
    const y = Math.floor((e.clientY - rect.top) / rect.height * SIZE);
    return [x, y];
  };

  const handleDown = (e) => {
    e.preventDefault();
    const [x, y] = coords(e);
    editor.beginStroke(x, y, tool, color);
  };
  const handleMove = (e) => {
    const [x, y] = coords(e);
    editor.moveStroke(x, y, tool, color);
  };
  const handleUp = () => editor.endStroke();

  return (
    <div className="relative">
      <canvas
        ref={canvasRef}
        width={DISP}
        height={DISP}
        onPointerDown={handleDown}
        onPointerMove={handleMove}
        onPointerUp={handleUp}
        onPointerLeave={handleUp}
        className="w-full touch-none border-2 border-slate-700 bg-slate-200 pixel-shadow"
        style={{ imageRendering: 'pixelated', aspectRatio: '1 / 1' }}
      />
      <div className="pointer-events-none absolute inset-0">
        {PART_LABELS.map(({ label, at }) => {
          const [x, y, w, h] = at;
          return (
            <span
              key={label}
              className="absolute -translate-x-1/2 -translate-y-1/2 whitespace-nowrap border border-slate-500/60 bg-white/70 px-1 text-[8px] font-semibold leading-tight text-slate-700"
              style={{
                left: `${((x + w / 2) / SIZE) * 100}%`,
                top: `${((y + h / 2) / SIZE) * 100}%`,
              }}
            >
              {label}
            </span>
          );
        })}
      </div>
    </div>
  );
}