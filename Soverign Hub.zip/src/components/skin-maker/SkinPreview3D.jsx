import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { buildSkinModel } from '@/lib/skinModel';

const SIZE = 64;

// Live 3D model of the skin. You can paint directly on the model (like
// Tynker's editor): a pointer hit on a body part maps through the part's
// UVs back to the exact pixel on the 64x64 texture. Dragging the
// background spins the model instead.
export default function SkinPreview3D({
  skinCanvas,
  version,
  rotating = true,
  onPaintStart,
  onPaintMove,
  onPaintEnd,
}) {
  const mountRef = useRef(null);
  const textureRef = useRef(null);
  const rotatingRef = useRef(rotating);
  const paintRef = useRef({ start: onPaintStart, move: onPaintMove, end: onPaintEnd });

  useEffect(() => { rotatingRef.current = rotating; }, [rotating]);
  useEffect(() => {
    paintRef.current = { start: onPaintStart, move: onPaintMove, end: onPaintEnd };
  });

  useEffect(() => {
    if (!skinCanvas) return;
    const mount = mountRef.current;
    const width = mount.clientWidth || 400;
    const height = mount.clientHeight || 400;

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x0b1020);

    const camera = new THREE.PerspectiveCamera(40, width / height, 0.1, 1000);
    camera.position.set(0, 18, 72);
    camera.lookAt(0, 14, 0);

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(width, height);
    renderer.setPixelRatio(window.devicePixelRatio);
    mount.appendChild(renderer.domElement);

    scene.add(new THREE.AmbientLight(0xffffff, 0.9));
    const dir = new THREE.DirectionalLight(0xffffff, 0.55);
    dir.position.set(20, 40, 20);
    scene.add(dir);

    const texture = new THREE.CanvasTexture(skinCanvas);
    texture.colorSpace = THREE.SRGBColorSpace;
    texture.flipY = false;
    texture.magFilter = THREE.NearestFilter;
    texture.minFilter = THREE.NearestFilter;
    texture.needsUpdate = true;
    textureRef.current = texture;

    const material = new THREE.MeshLambertMaterial({
      map: texture,
      transparent: true,
      alphaTest: 0.5,
      side: THREE.DoubleSide,
    });
    const model = buildSkinModel(material);
    scene.add(model);

    // --- paint on the model / orbit the background ---
    const ray = new THREE.Raycaster();
    const ndc = new THREE.Vector2();
    const getHit = (e) => {
      const rect = renderer.domElement.getBoundingClientRect();
      ndc.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      ndc.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;
      ray.setFromCamera(ndc, camera);
      const hits = ray.intersectObjects(model.children, false);
      if (!hits.length || !hits[0].uv) return null;
      // UVs are custom-mapped to the 64x64 texture with flipY=false,
      // so v=0 is the top of the image: floor(u*64) is the skin pixel.
      const x = Math.min(SIZE - 1, Math.max(0, Math.floor(hits[0].uv.x * SIZE)));
      const y = Math.min(SIZE - 1, Math.max(0, Math.floor(hits[0].uv.y * SIZE)));
      return { x, y };
    };

    let dragMode = null; // 'paint' | 'orbit' | null
    let lastX = 0;

    const onDown = (e) => {
      e.preventDefault();
      const hit = getHit(e);
      dragMode = hit ? 'paint' : 'orbit';
      lastX = e.clientX;
      if (hit) paintRef.current.start?.(hit.x, hit.y);
    };
    const onMove = (e) => {
      if (dragMode === 'paint') {
        const hit = getHit(e);
        if (hit) paintRef.current.move?.(hit.x, hit.y);
      } else if (dragMode === 'orbit') {
        model.rotation.y += (e.clientX - lastX) * 0.012;
        lastX = e.clientX;
      }
    };
    const onUp = () => {
      if (dragMode === 'paint') paintRef.current.end?.();
      dragMode = null;
    };

    renderer.domElement.style.touchAction = 'none';
    renderer.domElement.addEventListener('pointerdown', onDown);
    window.addEventListener('pointermove', onMove);
    window.addEventListener('pointerup', onUp);

    let raf;
    const animate = () => {
      raf = requestAnimationFrame(animate);
      if (rotatingRef.current && !dragMode) model.rotation.y += 0.012;
      renderer.render(scene, camera);
    };
    animate();

    const onResize = () => {
      const w = mount.clientWidth, h = mount.clientHeight;
      if (!w || !h) return;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };
    window.addEventListener('resize', onResize);

    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener('resize', onResize);
      renderer.domElement.removeEventListener('pointerdown', onDown);
      window.removeEventListener('pointermove', onMove);
      window.removeEventListener('pointerup', onUp);
      model.children.forEach((m) => m.geometry.dispose());
      material.dispose();
      texture.dispose();
      renderer.dispose();
      if (renderer.domElement.parentNode) mount.removeChild(renderer.domElement);
    };
  }, [skinCanvas]);

  // Refresh the texture when the editor changes.
  useEffect(() => {
    if (textureRef.current) textureRef.current.needsUpdate = true;
  }, [version, skinCanvas]);

  return <div ref={mountRef} className="h-full w-full" />;
}