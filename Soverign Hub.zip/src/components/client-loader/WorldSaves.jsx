const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useEffect, useRef, useState } from 'react';
import { FolderOpen, Upload, Download, Trash2, Loader2 } from 'lucide-react';

// World save manager: upload world files (zips, .dat, whatever your
// client uses), download them anywhere, private to your account.
export default function WorldSaves() {
  const [worlds, setWorlds] = useState(null); // null = loading
  const [uploading, setUploading] = useState(false);
  const inputRef = useRef(null);

  const load = async () => {
    setWorlds(await db.entities.WorldSave.list('-updated_date', 100));
  };

  useEffect(() => { load(); }, []);

  const handleFile = async (file) => {
    if (!file) return;
    setUploading(true);
    try {
      const { file_url } = await db.integrations.Core.UploadPublicFile({ file });
      await db.entities.WorldSave.create({ name: file.name, file_url, note: '' });
      await load();
    } finally {
      setUploading(false);
    }
  };

  const remove = async (w) => {
    await db.entities.WorldSave.delete(w.id);
    load();
  };

  return (
    <div className="space-y-5">
      <div>
        <h2 className="flex items-center gap-2 text-sm font-semibold text-slate-200">
          <FolderOpen className="h-4 w-4 text-indigo-300" /> World saves
        </h2>
        <p className="mt-0.5 text-xs text-slate-500">
          Back up your worlds here — upload a world file, then download it on any device.
        </p>
      </div>

      <button
        type="button"
        onClick={() => { if (!uploading) inputRef.current?.click(); }}
        disabled={uploading}
        className="flex w-full cursor-pointer flex-col items-center justify-center gap-3 border-2 border-dashed border-slate-700 bg-slate-900/40 px-6 py-10 text-center transition hover:border-indigo-500 hover:bg-slate-900/70"
      >
        {uploading ? (
          <>
            <Loader2 className="h-7 w-7 animate-spin text-indigo-300" />
            <p className="text-sm text-slate-300">Uploading your world…</p>
          </>
        ) : (
          <>
            <div className="flex h-14 w-14 items-center justify-center border-2 border-indigo-500/40 bg-indigo-500/15 text-indigo-300 pixel-shadow-sm">
              <Upload className="h-7 w-7" />
            </div>
            <p className="text-sm font-semibold text-white">Upload a world file</p>
            <p className="text-xs text-slate-500">Any file type — .zip, .dat, backups, whatever you need to keep.</p>
          </>
        )}
        <input
          ref={inputRef}
          type="file"
          onChange={(e) => handleFile(e.target.files?.[0])}
          className="hidden"
        />
      </button>

      {worlds === null ? (
        <div className="flex justify-center py-6">
          <Loader2 className="h-6 w-6 animate-spin text-slate-500" />
        </div>
      ) : worlds.length === 0 ? (
        <p className="border-2 border-dashed border-slate-800 px-4 py-5 text-center text-sm text-slate-500">
          No world saves yet — upload one above.
        </p>
      ) : (
        <ul className="divide-y-2 divide-slate-800 border-2 border-slate-800 bg-slate-900/50 pixel-shadow">
          {worlds.map((w) => (
            <li key={w.id} className="flex items-center gap-3 px-3 py-2.5">
              <span className="min-w-0 flex-1 truncate text-sm font-medium text-slate-200">{w.name}</span>
              <a
                href={w.file_url}
                download
                target="_blank"
                rel="noreferrer"
                title="Download world"
                className="inline-flex items-center gap-1 border-2 border-slate-700 px-2.5 py-1.5 text-xs font-medium text-slate-300 transition hover:bg-slate-800"
              >
                <Download className="h-3.5 w-3.5" /> Download
              </a>
              <button
                type="button"
                onClick={() => remove(w)}
                title="Delete world save"
                className="p-1 text-slate-500 transition hover:text-red-400"
              >
                <Trash2 className="h-4 w-4" />
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}