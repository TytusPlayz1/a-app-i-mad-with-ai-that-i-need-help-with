const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useEffect, useRef, useState } from 'react';
import { useLocation } from 'react-router-dom';
import { Maximize2, X, RotateCcw, Trash2 } from 'lucide-react';
import { useGameSession } from '@/lib/GameSessionContext';

import { wipeGameData, LAST_USER_KEY } from '@/lib/gameData';

// Persistent game frame. It stays mounted for the whole app session, so
// switching to Skin Maker or Home never reloads the client. The "tap to
// start" overlay gives the iframe keyboard focus and unlocks audio with a
// real user click — without it the game can't hear keystrokes or sound.
// Clients served through our proxy run same-origin, which lets us notice
// the client's built-in crash page and offer a one-click restart.
export default function GameFrame() {
  const { session, setSession } = useGameSession();
  const location = useLocation();
  const frameRef = useRef(null);
  const [started, setStarted] = useState(false);
  const [crashed, setCrashed] = useState(false);
  const [reloadKey, setReloadKey] = useState(0);

  const visible = !!session && location.pathname === '/client-loader';

  // In-game server lists and worlds live in this site's browser storage,
  // which every account on this device shares. Wipe them when the
  // signed-in account changes so data never crosses accounts — and stale
  // lists from another account stop crashing the server list.
  useEffect(() => {
    let alive = true;
    (async () => {
      try {
        const me = await db.auth.me();
        const last = localStorage.getItem(LAST_USER_KEY);
        if (alive && last && last !== me.id) await wipeGameData();
        if (alive) localStorage.setItem(LAST_USER_KEY, me.id);
      } catch { /* not signed in yet */ }
    })();
    return () => { alive = false; };
  }, []);

  // New client loaded -> require a fresh tap-to-start.
  useEffect(() => {
    setStarted(false);
    setCrashed(false);
  }, [session?.src]);

  // Re-focus the game whenever the frame becomes visible again.
  useEffect(() => {
    if (visible && started) {
      try { frameRef.current?.contentWindow?.focus?.(); } catch { /* cross-origin */ }
    }
  }, [visible, started]);

  // Watch for the client's crash page (same-origin only).
  useEffect(() => {
    if (!session || !started) return;
    const timer = setInterval(() => {
      try {
        const doc = frameRef.current?.contentDocument;
        const text = doc?.body?.innerText?.toLowerCase() || '';
        if (text.includes('crash')) setCrashed(true);
      } catch { /* cross-origin client */ }
    }, 2000);
    return () => clearInterval(timer);
  }, [session, started, reloadKey]);

  if (!session) return null;

  const start = () => {
    setStarted(true);
    try { frameRef.current?.contentWindow?.focus?.(); } catch { /* cross-origin */ }
  };

  const restart = () => {
    setCrashed(false);
    setStarted(true);
    setReloadKey((k) => k + 1);
    try { frameRef.current?.contentWindow?.focus?.(); } catch { /* cross-origin */ }
  };

  // All clients on this site share one browser storage, and Eaglercraft
  // crashes on the multiplayer screen when it finds server-list data left
  // by a different client build. Wipe just the game-related leftovers
  // (uploads, servers, and skins in the app itself are untouched).
  const resetGameData = async () => {
    const ok = window.confirm(
      'Reset game data? This clears in-game server lists, worlds, and settings saved by clients on this site. Your uploaded clients and skins are safe.'
    );
    if (!ok) return;
    await wipeGameData();
    restart();
  };

  return (
    <div className={visible ? 'block' : 'hidden'}>
      <div className="fixed bottom-0 left-0 right-0 top-14 z-30 flex flex-col bg-slate-950">
        <div className="flex shrink-0 items-center justify-between gap-3 border-b-2 border-slate-800 bg-slate-950 px-4 py-2">
          <span className="min-w-0 truncate text-sm font-medium text-slate-300">{session.name}</span>
          <div className="flex shrink-0 gap-2">
            <button
              type="button"
              onClick={restart}
              className="inline-flex items-center gap-1.5 border-2 border-slate-700 px-2.5 py-1.5 text-xs font-medium text-slate-300 transition hover:bg-slate-800"
            >
              <RotateCcw className="h-4 w-4" /> <span className="hidden sm:inline">Restart</span>
            </button>
            <button
              type="button"
              onClick={resetGameData}
              title="Clear in-game server lists, worlds, and settings saved by clients on this site — fixes multiplayer screen crashes"
              className="inline-flex items-center gap-1.5 border-2 border-slate-700 px-2.5 py-1.5 text-xs font-medium text-slate-300 transition hover:bg-slate-800"
            >
              <Trash2 className="h-4 w-4" /> <span className="hidden sm:inline">Reset data</span>
            </button>
            <button
              type="button"
              onClick={() => frameRef.current?.requestFullscreen?.()}
              className="inline-flex items-center gap-1.5 border-2 border-slate-700 px-2.5 py-1.5 text-xs font-medium text-slate-300 transition hover:bg-slate-800"
            >
              <Maximize2 className="h-4 w-4" /> <span className="hidden sm:inline">Fullscreen</span>
            </button>
            <button
              type="button"
              onClick={() => setSession(null)}
              className="inline-flex items-center gap-1.5 border-2 border-slate-700 px-2.5 py-1.5 text-xs font-medium text-slate-300 transition hover:bg-slate-800"
            >
              <X className="h-4 w-4" /> <span className="hidden sm:inline">Exit</span>
            </button>
          </div>
        </div>
        <div className="relative flex-1">
          {!started && (
            <button
              type="button"
              onClick={start}
              className="absolute inset-0 z-10 flex cursor-pointer flex-col items-center justify-center gap-3 bg-slate-950/90"
            >
              <span className="font-display text-base text-white">Tap to start</span>
              <span className="text-xs text-slate-400">Click to focus the game and enable audio.</span>
            </button>
          )}
          {crashed && (
            <div className="absolute inset-0 z-20 flex flex-col items-center justify-center gap-3 bg-slate-950/90 px-6 text-center">
              <span className="font-display text-sm text-red-400">The client stopped</span>
              <p className="max-w-md text-xs leading-relaxed text-slate-400">
                If this happened on the server list, leftover game data from another client is the usual cause — Reset game
                data below clears it. If it keeps stopping on one specific server, that server may only accept connections
                from approved sites; try a different one.
              </p>
              <div className="flex flex-wrap justify-center gap-3">
                <button
                  type="button"
                  onClick={restart}
                  className="border-2 border-indigo-400/60 bg-indigo-500 px-5 py-2.5 text-sm font-semibold text-white transition hover:bg-indigo-400 pixel-shadow"
                >
                  Restart client
                </button>
                <button
                  type="button"
                  onClick={resetGameData}
                  className="border-2 border-slate-600 bg-slate-800 px-5 py-2.5 text-sm font-semibold text-slate-200 transition hover:bg-slate-700"
                >
                  Reset game data
                </button>
              </div>
            </div>
          )}
          <iframe
            key={reloadKey}
            ref={frameRef}
            src={session.src}
            title="Minecraft Client"
            className="h-full w-full border-0"
            allow="fullscreen; autoplay; gamepad; pointer-lock; cross-origin-isolated; clipboard-write"
          />
        </div>
      </div>
    </div>
  );
}