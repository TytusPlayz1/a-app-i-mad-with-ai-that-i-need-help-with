const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useEffect, useState } from 'react';
import { Globe, Plus, Copy, Check, Trash2, Loader2 } from 'lucide-react';

// Saved wss:// server addresses, private to your account. Copy an
// address and paste it into the game's server list to join.
export default function ServerBrowser() {
  const [servers, setServers] = useState(null); // null = loading
  const [name, setName] = useState('');
  const [address, setAddress] = useState('');
  const [adding, setAdding] = useState(false);
  const [copiedId, setCopiedId] = useState(null);

  const load = async () => {
    setServers(await db.entities.ServerEntry.list('-updated_date', 100));
  };

  useEffect(() => { load(); }, []);

  const add = async (e) => {
    e.preventDefault();
    if (!name.trim() || !address.trim()) return;
    setAdding(true);
    try {
      await db.entities.ServerEntry.create({ name: name.trim(), address: address.trim(), note: '' });
      setName('');
      setAddress('');
      await load();
    } finally {
      setAdding(false);
    }
  };

  const copy = async (s) => {
    try { await navigator.clipboard.writeText(s.address); } catch { /* clipboard blocked */ }
    setCopiedId(s.id);
    setTimeout(() => setCopiedId(null), 1500);
  };

  const remove = async (s) => {
    await db.entities.ServerEntry.delete(s.id);
    load();
  };

  return (
    <div className="space-y-5">
      <div>
        <h2 className="flex items-center gap-2 text-sm font-semibold text-slate-200">
          <Globe className="h-4 w-4 text-indigo-300" /> Server browser
        </h2>
        <p className="mt-0.5 text-xs text-slate-500">
          Keep your favorite servers here. Copy the address, then paste it into the game's "Direct Connect" to join.
        </p>
      </div>

      <form onSubmit={add} className="flex flex-col gap-2 border-2 border-slate-800 bg-slate-900/50 p-3 pixel-shadow sm:flex-row">
        <input
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="Server name"
          maxLength={40}
          className="w-full border-2 border-slate-800 bg-slate-950 px-2.5 py-2 text-sm text-slate-100 focus:border-indigo-500 focus:outline-none sm:w-44"
        />
        <input
          value={address}
          onChange={(e) => setAddress(e.target.value)}
          placeholder="wss://your-server-address"
          className="w-full flex-1 border-2 border-slate-800 bg-slate-950 px-2.5 py-2 font-mono text-sm text-slate-100 focus:border-indigo-500 focus:outline-none"
        />
        <button
          type="submit"
          disabled={adding || !name.trim() || !address.trim()}
          className="inline-flex shrink-0 items-center justify-center gap-1.5 border-2 border-indigo-400/60 bg-indigo-500 px-4 py-2 text-sm font-semibold text-white transition hover:bg-indigo-400 pixel-shadow-sm disabled:opacity-60"
        >
          {adding ? <Loader2 className="h-4 w-4 animate-spin" /> : <Plus className="h-4 w-4" />} Add
        </button>
      </form>

      {servers === null ? (
        <div className="flex justify-center py-6">
          <Loader2 className="h-6 w-6 animate-spin text-slate-500" />
        </div>
      ) : servers.length === 0 ? (
        <p className="border-2 border-dashed border-slate-800 px-4 py-5 text-center text-sm text-slate-500">
          No servers saved yet — add one above and it's always one click away.
        </p>
      ) : (
        <ul className="divide-y-2 divide-slate-800 border-2 border-slate-800 bg-slate-900/50 pixel-shadow">
          {servers.map((s) => (
            <li key={s.id} className="flex items-center gap-3 px-3 py-2.5">
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-medium text-slate-200">{s.name}</p>
                <p className="truncate font-mono text-xs text-slate-500">{s.address}</p>
              </div>
              <button
                type="button"
                onClick={() => copy(s)}
                title="Copy address"
                className="inline-flex items-center gap-1 border-2 border-slate-700 px-2.5 py-1.5 text-xs font-medium text-slate-300 transition hover:bg-slate-800"
              >
                {copiedId === s.id ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Copy className="h-3.5 w-3.5" />}
                {copiedId === s.id ? 'Copied' : 'Copy'}
              </button>
              <button
                type="button"
                onClick={() => remove(s)}
                title="Delete server"
                className="p-1 text-slate-500 transition hover:text-red-400"
              >
                <Trash2 className="h-4 w-4" />
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}