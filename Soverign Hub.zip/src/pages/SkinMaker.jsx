const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { Suspense, lazy, useEffect, useRef, useState } from 'react';
import { Upload, Save, Loader2, Trash2, Check } from 'lucide-react';

import { toast } from '@/components/ui/use-toast';
import { Image } from '@/components/ui/image';
import SkinCanvas from '@/components/skin-maker/SkinCanvas';
// Code-split the 3D preview (three.js) so it only loads when needed.
const SkinPreview3D = lazy(() => import('@/components/skin-maker/SkinPreview3D'));
import Toolbar from '@/components/skin-maker/Toolbar';
import ColorPalette from '@/components/skin-maker/ColorPalette';
import { useSkinEditor } from '@/hooks/useSkinEditor';

// Turn an image URL into a loaded HTMLImageElement.
const loadImage = async (url) => {
  const img = new Image();
  await new Promise((res, rej) => { img.onload = res; img.onerror = rej; img.src = url; });
  return img;
};

export default function SkinMaker() {
  const [tool, setTool] = useState('pencil');
  const [color, setColor] = useState('#7c3aed');
  const [showGrid, setShowGrid] = useState(true);
  const [rotating, setRotating] = useState(true);
  const [name, setName] = useState('');
  const [currentSkinId, setCurrentSkinId] = useState(null);
  const [skins, setSkins] = useState(null); // null = loading
  const [saving, setSaving] = useState(false);
  const importRef = useRef(null);

  const editor = useSkinEditor({ onPick: (hex) => { if (hex) setColor(hex); } });

  const loadSkins = async () => {
    const list = await db.entities.Skin.list('-updated_date', 100);
    setSkins(list);
  };

  useEffect(() => { loadSkins(); }, []);

  const download = () => {
    const a = document.createElement('a');
    a.download = `${name.trim() || 'minecraft-skin'}.png`;
    a.href = editor.skinCanvas.toDataURL('image/png');
    a.click();
  };

  const importSkin = async (file) => {
    if (!file) return;
    if (file.type !== 'image/png' && !/\.png$/i.test(file.name)) {
      toast({ title: 'Only PNG skins can be imported.' });
      return;
    }
    const url = URL.createObjectURL(file);
    try {
      editor.loadFromImage(await loadImage(url));
      setCurrentSkinId(null);
      toast({ title: 'Skin imported', description: 'Edit it or save it to your skins.' });
    } finally {
      URL.revokeObjectURL(url);
    }
  };

  const saveSkin = async () => {
    if (saving) return;
    const n = name.trim() || 'my-skin';
    setSaving(true);
    try {
      const blob = await (await fetch(editor.skinCanvas.toDataURL('image/png'))).blob();
      const { file_url } = await db.integrations.Core.UploadPublicFile({
        file: new File([blob], `${n}.png`, { type: 'image/png' }),
      });
      if (currentSkinId) {
        await db.entities.Skin.update(currentSkinId, { name: n, file_url });
      } else {
        const rec = await db.entities.Skin.create({ name: n, file_url });
        setCurrentSkinId(rec.id);
      }
      await loadSkins();
      toast({ title: 'Skin saved', description: `"${n}" is in your skins list.` });
    } finally {
      setSaving(false);
    }
  };

  const loadSkin = async (s) => {
    const blob = await (await fetch(s.file_url)).blob();
    const url = URL.createObjectURL(blob);
    editor.loadFromImage(await loadImage(url));
    URL.revokeObjectURL(url);
    setName(s.name);
    setCurrentSkinId(s.id);
  };

  const deleteSkin = async (s) => {
    await db.entities.Skin.delete(s.id);
    if (currentSkinId === s.id) setCurrentSkinId(null);
    loadSkins();
  };

  return (
    <div className="grid gap-6 md:grid-cols-[minmax(0,1fr)_minmax(0,440px)]">
      <section className="space-y-4">
        <div>
          <h1 className="font-display text-base font-bold tracking-tight text-white">Skin Maker</h1>
          <p className="mt-1 text-sm text-slate-400">
            Start from a blank model or import a PNG, paint on the 3D model or the texture, then download a standard 64×64 Minecraft PNG.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <input
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Skin name"
            maxLength={40}
            className="w-44 border-2 border-slate-700 bg-slate-950 px-2.5 py-2 text-sm text-slate-100 focus:border-indigo-500 focus:outline-none"
          />
          <button
            type="button"
            onClick={() => importRef.current?.click()}
            className="inline-flex items-center gap-1.5 border-2 border-slate-700 bg-slate-900/60 px-3 py-2 text-sm font-medium text-slate-200 transition hover:bg-slate-800"
          >
            <Upload className="h-4 w-4" /> Import PNG
          </button>
          <button
            type="button"
            onClick={saveSkin}
            disabled={saving}
            className="inline-flex items-center gap-1.5 border-2 border-indigo-400/60 bg-indigo-500 px-3 py-2 text-sm font-semibold text-white transition hover:bg-indigo-400 pixel-shadow-sm disabled:opacity-60"
          >
            {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />} Save
          </button>
          <input
            ref={importRef}
            type="file"
            accept="image/png,.png"
            onChange={(e) => importSkin(e.target.files?.[0])}
            className="hidden"
          />
        </div>

        <Toolbar
          tool={tool}
          setTool={setTool}
          onUndo={editor.undo}
          onRedo={editor.redo}
          onClear={editor.clear}
          showGrid={showGrid}
          setShowGrid={setShowGrid}
          onDownload={download}
          canUndo={editor.canUndo}
          canRedo={editor.canRedo}
        />
        <SkinCanvas editor={editor} tool={tool} color={color} showGrid={showGrid} />
        <div className="border-2 border-slate-800 bg-slate-900/50 p-4 pixel-shadow">
          <ColorPalette color={color} setColor={setColor} />
        </div>
      </section>

      <section className="space-y-4">
        <div className="overflow-hidden border-2 border-slate-800 bg-slate-900/50 pixel-shadow">
          <div className="flex items-center justify-between border-b-2 border-slate-800 px-4 py-2.5">
            <span className="text-sm font-semibold text-slate-200">3D Model — paint right on it</span>
            <button
              type="button"
              onClick={() => setRotating((r) => !r)}
              className="border-2 border-slate-700 px-2 py-1 text-xs font-medium text-slate-300 transition hover:bg-slate-800"
            >
              {rotating ? 'Pause' : 'Rotate'}
            </button>
          </div>
          <div className="h-[420px] w-full">
            <Suspense
              fallback={
                <div className="flex h-full items-center justify-center">
                  <Loader2 className="h-6 w-6 animate-spin text-slate-500" />
                </div>
              }
            >
              <SkinPreview3D
                skinCanvas={editor.skinCanvas}
                version={editor.version}
                rotating={rotating}
                onPaintStart={(x, y) => editor.beginStroke(x, y, tool, color)}
                onPaintMove={(x, y) => editor.moveStroke(x, y, tool, color)}
                onPaintEnd={() => editor.endStroke()}
              />
            </Suspense>
          </div>
        </div>

        <div className="border-2 border-slate-800 bg-slate-900/50 pixel-shadow">
          <div className="flex items-center justify-between border-b-2 border-slate-800 px-4 py-2.5">
            <span className="text-sm font-semibold text-slate-200">My Skins</span>
            <span className="text-xs text-slate-500">saved to your account</span>
          </div>
          {skins === null ? (
            <div className="flex justify-center py-6">
              <Loader2 className="h-6 w-6 animate-spin text-slate-500" />
            </div>
          ) : skins.length === 0 ? (
            <p className="px-4 py-5 text-center text-sm text-slate-500">
              No saved skins yet — hit Save and they'll appear here to reload any time.
            </p>
          ) : (
            <ul className="max-h-72 divide-y-2 divide-slate-800 overflow-y-auto">
              {skins.map((s) => (
                <li key={s.id} className="flex items-center gap-3 px-3 py-2">
                  <Image
                    src={s.file_url}
                    alt={s.name}
                    className="h-9 w-9 shrink-0 border-2 border-slate-700"
                    fittingType="fill"
                  />
                  <button
                    type="button"
                    onClick={() => loadSkin(s)}
                    className="min-w-0 flex-1 truncate text-left text-sm text-slate-200 transition hover:text-indigo-300"
                    title={`Load "${s.name}"`}
                  >
                    {s.name}
                    {s.id === currentSkinId && (
                      <span className="ml-2 inline-flex items-center gap-0.5 text-[10px] font-semibold text-indigo-400">
                        <Check className="h-3 w-3" /> editing
                      </span>
                    )}
                  </button>
                  <button
                    type="button"
                    onClick={() => deleteSkin(s)}
                    className="p-1 text-slate-500 transition hover:text-red-400"
                    title={`Delete "${s.name}"`}
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </li>
              ))}
            </ul>
          )}
        </div>
      </section>
    </div>
  );
}