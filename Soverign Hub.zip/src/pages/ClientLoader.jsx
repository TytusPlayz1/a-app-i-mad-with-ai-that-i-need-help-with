const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useEffect, useRef, useState } from 'react';
import { Upload, Star, Trash2, Play, Loader2, Gamepad2 } from 'lucide-react';

import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useGameSession } from '@/lib/GameSessionContext';
import ServerBrowser from '@/components/client-loader/ServerBrowser';
import WorldSaves from '@/components/client-loader/WorldSaves';

const CLIENTS = ['Eaglercraft', 'Resent', 'Starlike'];

// Serve clients from our own origin so their server connections aren't
// rejected — the file-storage origin is what crashed the game on join.
const proxySrc = (id) => `/functions/serveClient?id=${id}`;

export default function ClientLoader() {
  const setSession = useGameSession().setSession;
  const [clients, setClients] = useState(null); // null = loading
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState('');
  const [dragOver, setDragOver] = useState(false);
  const inputRef = useRef(null);

  const load = async () => {
    const list = await db.entities.ClientFile.list('-updated_date', 100);
    list.sort((a, b) => Number(b.favorite || false) - Number(a.favorite || false));
    setClients(list);
  };

  useEffect(() => { load(); }, []);

  const handleFile = async (file) => {
    setError('');
    if (!file) return;
    if (!/\.html?$/i.test(file.name)) {
      setError(
        'Only single-file .html clients can be loaded. If your download is a .zip, extract it first and upload the .html file inside.'
      );
      return;
    }
    // Single-file clients only: if the HTML references a companion file
    // (js/…, ./launch.html …) that wasn't uploaded, the game would load a
    // dead black screen. Catch it up front with a clear message.
    const text = await file.text();
    const rel = text.match(/\b(?:src|href)\s*=\s*["'](?!https?:|data:|blob:|#|\/\/)([^"']*\/[^"']*)["']/i);
    if (rel) {
      setError(
        `This client needs extra files that weren't uploaded (it references "${rel[1]}"), so it can't run here. Download the all-in-one / offline single-file build of the client and upload that .html instead.`
      );
      return;
    }
    setUploading(true);
    try {
      const { file_url } = await db.integrations.Core.UploadPublicFile({ file });
      const rec = await db.entities.ClientFile.create({ name: file.name, file_url, note: '', favorite: false });
      await load();
      setSession({ name: file.name, src: proxySrc(rec.id) });
    } catch (err) {
      // Fall back to a local-only session so the game still runs.
      setSession({ name: file.name, src: URL.createObjectURL(file) });
      setError(
        `Cloud save failed, so this run is local only and it will not appear in your list: ${String(err).slice(0, 140)}`
      );
    } finally {
      setUploading(false);
    }
  };

  const launch = (c) => setSession({ name: c.name, src: proxySrc(c.id) });
  const toggleFavorite = async (c) => {
    await db.entities.ClientFile.update(c.id, { favorite: !c.favorite });
    load();
  };
  const saveNote = async (c, note) => {
    await db.entities.ClientFile.update(c.id, { note });
  };
  const remove = async (c) => {
    await db.entities.ClientFile.delete(c.id);
    load();
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-base font-bold tracking-tight text-white">Client Loader</h1>
        <p className="mt-1 text-sm text-slate-400">
          Load any Minecraft web client you have the file for — it runs right here and keeps running while you switch tabs.
        </p>
        <div className="mt-3 flex flex-wrap gap-2">
          {CLIENTS.map((c) => (
            <span
              key={c}
              className="border-2 border-indigo-500/40 bg-indigo-500/10 px-2.5 py-1 text-xs font-semibold text-indigo-300"
            >
              {c}
            </span>
          ))}
          <span className="border-2 border-slate-700 bg-slate-900/60 px-2.5 py-1 text-xs font-semibold text-slate-400">
            + any single-file client
          </span>
        </div>
      </div>

      <Tabs defaultValue="clients">
        <TabsList className="grid w-full max-w-md grid-cols-3 border-2 border-slate-800 bg-slate-900/60 p-1">
          <TabsTrigger
            value="clients"
            className="border-2 border-transparent px-3 py-1.5 text-xs font-semibold text-slate-400 transition data-[state=active]:border-indigo-400/60 data-[state=active]:bg-indigo-500 data-[state=active]:text-white"
          >
            Clients
          </TabsTrigger>
          <TabsTrigger
            value="servers"
            className="border-2 border-transparent px-3 py-1.5 text-xs font-semibold text-slate-400 transition data-[state=active]:border-indigo-400/60 data-[state=active]:bg-indigo-500 data-[state=active]:text-white"
          >
            Servers
          </TabsTrigger>
          <TabsTrigger
            value="worlds"
            className="border-2 border-transparent px-3 py-1.5 text-xs font-semibold text-slate-400 transition data-[state=active]:border-indigo-400/60 data-[state=active]:bg-indigo-500 data-[state=active]:text-white"
          >
            Worlds
          </TabsTrigger>
        </TabsList>

        <TabsContent value="clients" className="mt-5 space-y-6">
          <div>
            <div
              onClick={() => { if (!uploading) inputRef.current?.click(); }}
              onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
              onDragLeave={() => setDragOver(false)}
              onDrop={(e) => {
                e.preventDefault();
                setDragOver(false);
                handleFile(e.dataTransfer.files?.[0]);
              }}
              className={`flex cursor-pointer flex-col items-center justify-center gap-4 border-2 border-dashed bg-slate-900/40 px-6 py-14 text-center transition ${
                dragOver
                  ? 'border-indigo-400 bg-slate-900/80'
                  : 'border-slate-700 hover:border-indigo-500 hover:bg-slate-900/70'
              }`}
            >
              {uploading ? (
                <div className="flex flex-col items-center gap-3 py-2">
                  <Loader2 className="h-8 w-8 animate-spin text-indigo-300" />
                  <p className="text-sm text-slate-300">Saving your client…</p>
                </div>
              ) : (
                <>
                  <div className="flex h-16 w-16 items-center justify-center border-2 border-indigo-500/40 bg-indigo-500/15 text-indigo-300 pixel-shadow-sm">
                    <Gamepad2 className="h-8 w-8" />
                  </div>
                  <div>
                    <p className="text-lg font-semibold text-white">Drop your client here</p>
                    <p className="mt-1 text-sm text-slate-400">
                      or click to pick the client's .html file. Every upload is saved to your account.
                    </p>
                  </div>
                  <span className="inline-flex items-center gap-2 border-2 border-indigo-400/60 bg-indigo-500 px-5 py-2.5 text-sm font-semibold text-white pixel-shadow">
                    <Upload className="h-4 w-4" /> Choose file
                  </span>
                </>
              )}
              <input
                ref={inputRef}
                type="file"
                accept=".html,.htm,text/html"
                onChange={(e) => handleFile(e.target.files?.[0])}
                className="hidden"
              />
            </div>
            {error && (
              <p className="mt-3 border-2 border-red-500/40 bg-red-500/10 px-4 py-2.5 text-sm text-red-300">{error}</p>
            )}
          </div>

          <div>
            <h2 className="text-sm font-semibold text-slate-200">My clients</h2>
            <p className="mt-0.5 text-xs text-slate-500">
              Everything you upload is saved to your account — star your favorites for one-click launch, add notes for versions.
            </p>
            {clients === null ? (
              <div className="mt-4 flex justify-center py-6">
                <Loader2 className="h-6 w-6 animate-spin text-slate-500" />
              </div>
            ) : clients.length === 0 ? (
              <p className="mt-3 border-2 border-dashed border-slate-800 px-4 py-5 text-center text-sm text-slate-500">
                No clients yet — upload one above and it will show up here.
              </p>
            ) : (
              <ul className="mt-3 grid gap-3 sm:grid-cols-2">
                {clients.map((c) => (
                  <li key={c.id} className="border-2 border-slate-800 bg-slate-900/50 p-3 pixel-shadow">
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => toggleFavorite(c)}
                        title={c.favorite ? 'Unstar' : 'Star this client'}
                        className={c.favorite ? 'text-amber-400' : 'text-slate-600 hover:text-slate-400'}
                      >
                        <Star className={`h-4 w-4 ${c.favorite ? 'fill-amber-400' : ''}`} />
                      </button>
                      <span className="min-w-0 flex-1 truncate text-sm font-medium text-slate-200">{c.name}</span>
                      <button
                        type="button"
                        onClick={() => remove(c)}
                        title="Delete this client"
                        className="p-1 text-slate-500 hover:text-red-400"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                    <input
                      defaultValue={c.note || ''}
                      placeholder="Note (version, what it's for…)"
                      onBlur={(e) => saveNote(c, e.target.value)}
                      className="mt-2 w-full border-2 border-slate-800 bg-slate-950 px-2 py-1 text-xs text-slate-300 focus:border-indigo-500 focus:outline-none"
                    />
                    <button
                      type="button"
                      onClick={() => launch(c)}
                      className="mt-2 inline-flex w-full items-center justify-center gap-1.5 border-2 border-indigo-400/60 bg-indigo-500 px-3 py-1.5 text-xs font-semibold text-white hover:bg-indigo-400 pixel-shadow-sm"
                    >
                      <Play className="h-3.5 w-3.5" /> Launch
                    </button>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </TabsContent>

        <TabsContent value="servers" className="mt-5">
          <ServerBrowser />
        </TabsContent>

        <TabsContent value="worlds" className="mt-5">
          <WorldSaves />
        </TabsContent>
      </Tabs>
    </div>
  );
}