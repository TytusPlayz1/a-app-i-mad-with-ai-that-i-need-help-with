import React from 'react';
import AccountCard from '@/components/settings/AccountCard';
import SavedDataCard from '@/components/settings/SavedDataCard';
import DeviceDataCard from '@/components/settings/DeviceDataCard';

export default function Settings() {
  return (
    <div className="mx-auto max-w-3xl space-y-6">
      <div>
        <h1 className="font-display text-base font-bold tracking-tight text-white">Settings</h1>
        <p className="mt-1 text-sm text-slate-400">
          Manage your account and your data. Clients, servers, world saves, and skins are stored on your account —
          not this device's address — so they're with you wherever you sign in.
        </p>
      </div>
      <AccountCard />
      <SavedDataCard />
      <DeviceDataCard />
    </div>
  );
}