import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Gamepad2, Palette, Globe, FolderOpen, ArrowRight, ShieldCheck } from 'lucide-react';

const OPTIONS = [
  {
    to: '/client-loader',
    icon: Gamepad2,
    title: 'Client Loader',
    desc: 'Play Eaglercraft, Resent, Starlike, and more — right in your browser, saved to your account and running even while you switch tabs.',
    accent: 'from-indigo-500/20 to-indigo-500/5 text-indigo-300 border-indigo-500/30',
  },
  {
    to: '/skin-maker',
    icon: Palette,
    title: 'Skin Maker',
    desc: 'Start from a blank model, paint directly in 3D, and download a Minecraft-ready skin.',
    accent: 'from-fuchsia-500/20 to-fuchsia-500/5 text-fuchsia-300 border-fuchsia-500/30',
  },
];

const MINI = [
  {
    icon: Globe,
    title: 'Server browser',
    desc: 'Keep your favorite wss:// servers one copy away.',
  },
  {
    icon: FolderOpen,
    title: 'World saves',
    desc: 'Upload and download world files from anywhere.',
  },
];

const fadeUp = {
  hidden: { opacity: 0, y: 16 },
  show: { opacity: 1, y: 0 },
};

export default function HomePage() {
  return (
    <div className="flex flex-col items-center py-8 text-center sm:py-14">
      <motion.div
        initial="hidden"
        animate="show"
        variants={fadeUp}
        transition={{ duration: 0.5 }}
        className="relative"
      >
        <div className="pointer-events-none absolute -top-7 left-1/2 hidden -translate-x-[130px] sm:block">
          <div className="h-5 w-5 border-2 border-slate-700 bg-indigo-500/40 pixel-shadow-sm" />
        </div>
        <div className="pointer-events-none absolute -top-9 left-1/2 hidden -translate-x-[70px] sm:block">
          <div className="h-4 w-4 border-2 border-slate-700 bg-fuchsia-500/40 pixel-shadow-sm" />
        </div>
        <div className="pointer-events-none absolute -top-6 left-1/2 hidden translate-x-[86px] sm:block">
          <div className="h-4 w-4 border-2 border-slate-700 bg-indigo-400/40 pixel-shadow-sm" />
        </div>
        <h1 className="font-display text-2xl font-bold tracking-tight text-white sm:text-4xl">
          Sovereign<span className="text-indigo-400">Client</span>
        </h1>
      </motion.div>
      <motion.p
        initial="hidden"
        animate="show"
        variants={fadeUp}
        transition={{ duration: 0.5, delay: 0.1 }}
        className="mt-4 max-w-xl text-sm text-slate-400 sm:text-base"
      >
        Your all-in-one hub for playing Minecraft web clients and crafting custom skins — everything stays yours, saved to
        your account.
      </motion.p>
      <motion.div
        initial="hidden"
        animate="show"
        variants={fadeUp}
        transition={{ duration: 0.5, delay: 0.2 }}
        className="mt-5 inline-flex items-center gap-2 border-2 border-emerald-500/30 bg-emerald-500/10 px-3 py-1.5 text-xs font-medium text-emerald-300"
      >
        <ShieldCheck className="h-3.5 w-3.5" /> Private to you — only you can see your clients, servers, worlds, and skins
      </motion.div>

      <div className="mt-10 grid w-full max-w-3xl gap-5 sm:grid-cols-2">
        {OPTIONS.map((o, i) => {
          const Icon = o.icon;
          return (
            <motion.div
              key={o.to}
              initial="hidden"
              animate="show"
              variants={fadeUp}
              transition={{ duration: 0.5, delay: 0.25 + i * 0.1 }}
            >
              <Link
                to={o.to}
                className={`group flex h-full flex-col items-center gap-4 rounded-none border-2 bg-gradient-to-b p-8 transition hover:scale-[1.02] pixel-shadow ${o.accent}`}
              >
                <div className="flex h-16 w-16 items-center justify-center border-2 border-slate-950/30 bg-slate-950/40 pixel-shadow-sm">
                  <Icon className="h-8 w-8" />
                </div>
                <div>
                  <h2 className="text-xl font-bold text-white">{o.title}</h2>
                  <p className="mt-1.5 text-sm text-slate-400">{o.desc}</p>
                </div>
                <span className="mt-2 inline-flex items-center gap-1.5 text-sm font-semibold opacity-80 transition group-hover:opacity-100">
                  Open <ArrowRight className="h-4 w-4 transition group-hover:translate-x-0.5" />
                </span>
              </Link>
            </motion.div>
          );
        })}
      </div>

      <motion.div
        initial="hidden"
        animate="show"
        variants={fadeUp}
        transition={{ duration: 0.5, delay: 0.45 }}
        className="mt-5 grid w-full max-w-3xl gap-5 sm:grid-cols-2"
      >
        {MINI.map((m) => {
          const Icon = m.icon;
          return (
            <Link
              key={m.title}
              to="/client-loader"
              className="group flex items-center gap-4 border-2 border-slate-800 bg-slate-900/40 px-5 py-4 text-left transition hover:border-indigo-500/50 hover:bg-slate-900/70 pixel-shadow-sm"
            >
              <div className="flex h-11 w-11 shrink-0 items-center justify-center border-2 border-indigo-500/40 bg-indigo-500/15 text-indigo-300">
                <Icon className="h-5 w-5" />
              </div>
              <div className="min-w-0">
                <h3 className="text-sm font-bold text-white">{m.title}</h3>
                <p className="mt-0.5 truncate text-xs text-slate-500">{m.desc}</p>
              </div>
              <ArrowRight className="ml-auto h-4 w-4 shrink-0 text-slate-600 transition group-hover:translate-x-0.5 group-hover:text-indigo-400" />
            </Link>
          );
        })}
      </motion.div>
    </div>
  );
}